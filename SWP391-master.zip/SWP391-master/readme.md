[![Java CI with Maven](https://github.com/eung-eung/SWP391/actions/workflows/maven.yml/badge.svg?branch=master)](https://github.com/eung-eung/SWP391/actions/workflows/maven.yml)

```diff
🛑🛑🛑
-### When adding new servlet, please fix replace javax to jakarta at import lines


@@  Always check time commit of EcommercePlatform.sql for updating newest data @@
```
